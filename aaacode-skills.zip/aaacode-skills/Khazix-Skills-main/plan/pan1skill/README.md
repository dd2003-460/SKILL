# Planning with Files Skill 使用说明

## 简介
用Markdown文件进行持久化任务规划，适用于长任务、多步骤任务。

## 适用场景
- 需要中断后继续的任务。
- 与其他Skills协作，planning负责规划，其他执行。

## 示例
输入：规划一个网站开发项目。

输出：todo.md和plan.md文件内容。